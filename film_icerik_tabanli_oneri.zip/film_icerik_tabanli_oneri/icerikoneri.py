import pandas as pd
# CSV dosyasını yüklüyoruz 
df_movie = pd.read_csv('movies_metadata.csv', low_memory=False)

# 'overview' sütununu temizliyoruz ve boş değerleri kaldırıyoruz
df_movie['overview'] = df_movie['overview'].fillna('')

# Veri setini popüler filmlerle sınırlandırıyoruz
df_movie['popularity'] = pd.to_numeric(df_movie['popularity'], errors='coerce').fillna(0)
populer_filmler = df_movie.nlargest(1000, 'popularity')  # İlk 1000 popüler filmi seçiyoruz

# `overview` sütununu kelimelere dönüştürerek Jaccard benzerliğini hesaplamak için işliyoruz
def get_word_set(text):
    return set(text.lower().split())

populer_filmler['word_set'] = populer_filmler['overview'].apply(get_word_set)

# Jaccard benzerliği ile benzer filmleri öneren fonksiyon
def jaccard_benzerligi(set1, set2):
    intersection = len(set1 & set2)
    union = len(set1 | set2)
    return intersection / union if union != 0 else 0

def film_onerisi(film_adi, n_oneri=5):
    film_indeksi = populer_filmler[populer_filmler['title'].str.lower() == film_adi.lower()].index
    
    if film_indeksi.empty:
        return [f"Film '{film_adi}' bulunamadı."]

    film_indeksi = film_indeksi[0]
    current_word_set = populer_filmler['word_set'].iloc[film_indeksi]

    # Jaccard benzerliği hesaplayarak önerilerde bulunuyoruz
    jaccard_scores = [
        (idx, jaccard_benzerligi(current_word_set, populer_filmler['word_set'].iloc[idx]))
        for idx in range(populer_filmler.shape[0])
    ]

    # Jaccard benzerliklerine göre en benzer filmleri sıralıyoruz
    jaccard_scores = sorted(jaccard_scores, key=lambda x: x[1], reverse=True)

    # En benzer ilk 'n_oneri' filmi öneriyoruz
    onerilen_filmler = []
    for i in range(1, n_oneri + 1):
        onerilen_filmler.append(populer_filmler['title'].iloc[jaccard_scores[i][0]])

    return onerilen_filmler

# Kullanıcıdan hangi filmi izlediğini soruyoruz
izlenen_film = input("Hangi filmi izlediniz? ")
onerilen_filmler = film_onerisi(izlenen_film)

# Önerilen filmleri alt alta yazdırıyoruz
print("Önerilen filmler:")
for film in onerilen_filmler:
    print(f"- {film}")
